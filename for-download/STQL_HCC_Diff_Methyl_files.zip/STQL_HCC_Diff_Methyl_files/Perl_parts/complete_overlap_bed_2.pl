#!/usr/bin/perl
use strict; use warnings;

#The directory containing the input bed files
my $bed_dir = "/mnt/nas2/hoyu/TestSTQL_promoter_methyl/final_run";

#The previously extracted hg19 protein coding genes annotation (using STQL)
my $complete = "/mnt/nas2/hoyu/TestSTQL_promoter_methyl/complete.bed";

my @beds = qw(318N.bed  333N.bed  353N.bed  419N.bed  434N.bed  458N.bed  485N.bed  524N.bed  551N.bed  675N.bed   NL-6.bed 190T.bed  318T.bed  333T.bed  353T.bed  419T.bed  434T.bed  458T.bed  485T.bed  524T.bed  551T.bed  675T.bed  NL-1.bed   NL-7.bed 293N.bed  321N.bed  339N.bed  391N.bed  432N.bed  442N.bed  464N.bed  495N.bed  531N.bed  663N.bed  676N.bed  NL-10.bed  NL-8.bed 293T.bed  321T.bed  339T.bed  391T.bed  432T.bed  442T.bed  464T.bed  495T.bed  531T.bed  663T.bed  676T.bed  NL-11.bed  NL-9.bed 304N.bed  328N.bed  350N.bed  414N.bed  433N.bed  447N.bed  469N.bed  506N.bed  534N.bed  672N.bed  688N.bed  NL-3.bed 304T.bed  328T.bed  350T.bed  414T.bed  433T.bed  447T.bed  469T.bed  506T.bed  534T.bed  672T.bed  688T.bed  NL-5.bed 190N.bed);

my %Tdata;
my %Ndata;

Collect the methylation signals in the bed files for each chromosome coordinate
for my $bed (@beds) {
	my $in = $bed_dir . "/$bed";
	open IN, "<$in" or die "can't open $in\n";
	while (<IN>) {
		chomp;
		my @line = split(/\s+/,$_);
		#chr,start,end,methyl_signal
		my ($chr,$start,$end,$val) = ($line[0],$line[1],$line[2],$line[3]);
		
		#chromosome coordinate
		my $loc = "$chr\t$start\t$end";
		
		#if the bed file is a T sample
		if ($bed =~ m/T.bed/) {
			push @{$Tdata{$loc}}, $val;
		}
		#if the bed file is a N sample
		elsif ($bed =~ m/N.bed/) {
			push @{$Ndata{$loc}}, $val;
		}
			#The 2 hashes would hold the methylation signals for each sample at the chromosome coords represented by the samples
		
	}
	close IN;
}

my $out_t = $bed_dir . "/T_avg.bed";
my $out_n = $bed_dir . "/N_avg.bed";

open OUT_T, ">$out_t" or die "can't open $out_t\n";
open OUT_N, ">$out_n" or die "can't open $out_n\n";

#Loop over the hashes and take a mean of the signals for each chromosome coord, then output to bed file
for my $loc (keys %Tdata) {
	my $mean = mean(@{$Tdata{$loc}});
	print OUT_T $loc . "\t$mean\n";
}

for my $loc (keys %Ndata) {
	my $mean = mean(@{$Ndata{$loc}});
	print OUT_N $loc . "\t$mean\n";
}
close OUT_T;
close OUT_N;

#Sort the outputted bed file
my $t_sorted = $bed_dir . "/T_avg.sorted.bed";
my $n_sorted = $bed_dir . "/N_avg.sorted.bed";

%Tdata = ();
%Ndata = ();

system("bedtools sort -i $out_t > $t_sorted");
system("bedtools sort -i $out_n > $n_sorted");


###So far, the above code mimics the 'UNION ALL' and 'GROUP BY' parts of the STQL, shown below:###
#FOR TRACK T IN (category = 'HCC methylation', fname like '%T%')
#SELECT chr, chrstart, chrend, value 
#FROM T
#COMBINED WITH UNION ALL AS TResults;
#
#FOR TRACK N IN (category = 'HCC methylation', fname like '%N%' and fname not like '%L%')
#SELECT chr, chrstart, chrend, value 
#FROM N
#COMBINED WITH UNION ALL AS NResults;
#
#Create TRACK TResultsG AS
#SELECT chr, chrstart, chrend, avg(value) AS value
#FROM TResults GROUP BY chr, chrstart, chrend;
#
#Create TRACK NResultsG AS
#SELECT chr, chrstart, chrend, avg(value) AS value
#FROM NResults GROUP BY chr, chrstart, chrend;
#
###


#Find which signals in the intermediary .bed files overlap the gene annotation, create intermediary file ".overlaps"
for my $bed (qw(T_avg.sorted.bed N_avg.sorted.bed)) {
	my $in = $bed_dir . "/$bed";
	
	my $out = $in . ".overlaps";
	
	print $out . "\n";
	system("bedtools intersect -wb -a $complete -b $in > $out");
	
}

#And merge the overlapping signals in each gene region, output to the next intermediary file ".overlaps.mean"
for my $bed (qw(T_avg.sorted.bed N_avg.sorted.bed)) {
	my $in = $bed_dir . "/$bed" . ".overlaps";
	my $out = $in . ".mean";
	
	open IN, "<$in" or die "can't open $in\n";
	open OUT, ">$out" or die "can't open $out\n";
	
	my @head_line = split (/\s+/,<IN>);
	my ($gene, $signal) = ($head_line[3], $head_line[7]);
	my ($sum, $num) = (0, 0);
	$sum += $signal;
	$num += 1;
	my $prev_gene = $gene;
	while (<IN>) {
		chomp;
		my @line = split (/\s+/,$_);
		($gene, $signal) = ($line[3], $line[7]);
		
		if ($gene ne $prev_gene) {
			my $avg = $sum/$num;
			print OUT "$prev_gene\t$avg\n";
			
			$sum=0;
			$num=0;
		}
		
		$sum += $signal;
		$num += 1;
		
		
		$prev_gene = $gene;
	}
	
	my $avg = $sum/$num;
	print OUT "$prev_gene\t$avg\n";
	
	
	close IN;
	close OUT;

}


###The above should mimic the 'overlaps with' part of the STQL, shown below:###
#CREATE TRACK Step3Results AS
#SELECT s2.chr, s2.chrstart, s2.chrend, avg(tr.value) AS value
#FROM Step2Results s2, TResultsG tr
#WHERE s2 overlaps with tr
#GROUP BY s2.chr, s2.chrstart, s2.chrend;
#
#CREATE TRACK Step4Results AS
#SELECT s2.chr, s2.chrstart, s2.chrend, avg(nr.value) AS value
#FROM Step2Results s2, NResultsG nr
#WHERE s2 overlaps with nr
#GROUP BY s2.chr, s2.chrstart, s2.chrend;
#
###


#Recollect the T/N "overlaps.mean" data to hashes and then do a simple fold change calculation and output to final .bed file "fold_change_2.bed"
my %T_mean_data;
my %N_mean_data;

for my $bed (qw(T_avg.sorted.bed N_avg.sorted.bed)) {
	my $in = $bed_dir . "/$bed" . ".overlaps.mean";
	open IN, "<$in" or die "can't open $in\n";
	
	while (<IN>) {
		chomp;
		my @line = split (/\s+/, $_);
		my ($gene, $signal) = ($line[0], $line[1]);
		if ($bed =~ m/T_avg/) {
			$T_mean_data{$gene} .= $signal;
		} elsif ($bed =~ m/N_avg/) {
			$N_mean_data{$gene} .= $signal;
		}
	}
	close IN;
	
}

#Visualizing the data using DataBrowser.pm
#print "N_mean_data\n";
#browse(\%N_mean_data);
#print "T_mean_data\n";
#browse(\%T_mean_data);

my $size_n = keys %N_mean_data;
my $size_t = keys %T_mean_data;

print $size_n . "\n";
print $size_t . "\n";

my $out = $bed_dir . "/fold_change_2.bed";
open OUT, ">$out" or die "can't open $out\n";

for my $gene (sort keys %N_mean_data) {
	my $mean_T = $T_mean_data{$gene};
	my $mean_N = $N_mean_data{$gene};
	my $fold_change = $mean_T/$mean_N;
	
	if ($gene =~ m/(.*):(.*)-(.*)/) {
		my $chr = $1;
		my $start = $2;
		my $end = $3;
		print OUT "$chr\t$start\t$end\t$fold_change\n";
	}
	
}
close OUT;

###Fold change calculation step in STQL:
#CREATE TRACK Step5Results AS
#SELECT d.chr, d.chrstart, d.chrend,
#d.value/ e.value as value
#FROM Step3Results d,
#(SELECT chr, chrstart, chrend, value
#FROM Step4Results
#WHERE value != 0) e
#WHERE d coincides with e;

#SELECT * FROM Step5Results;
###


sub mean {
    my (@data) = @_;
    my $sum;
    foreach (@data) {
        $sum += $_;
    }
    return ( $sum / @data );
}