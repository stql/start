#!/usr/bin/perl
use strict; use warnings;

my $wig_dir = "/mnt/nas2/hoyu/STQL/HCC_aligned_to_wig";

my @wigs = qw(190N.wig	318N.wig  333N.wig  353N.wig  419N.wig  434N.wig  458N.wig  485N.wig  524N.wig  551N.wig  675N.wig   NL-6.wig 190T.wig  318T.wig  333T.wig  353T.wig  419T.wig  434T.wig  458T.wig  485T.wig  524T.wig  551T.wig  675T.wig  NL-1.wig   NL-7.wig 293N.wig  321N.wig  339N.wig  391N.wig  432N.wig  442N.wig  464N.wig  495N.wig  531N.wig  663N.wig  676N.wig  NL-10.wig  NL-8.wig 293T.wig  321T.wig  339T.wig  391T.wig  432T.wig  442T.wig  464T.wig  495T.wig  531T.wig  663T.wig  676T.wig  NL-11.wig  NL-9.wig 304N.wig  328N.wig  350N.wig  414N.wig  433N.wig  447N.wig  469N.wig  506N.wig  534N.wig  672N.wig  688N.wig  NL-3.wig 304T.wig  328T.wig  350T.wig  414T.wig  433T.wig  447T.wig  469T.wig  506T.wig  534T.wig  672T.wig  688T.wig  NL-5.wig);

for my $wig (@wigs) {
	my $in = $wig_dir . "/$wig";
	
	my $bed = $wig;
	$bed =~ tr/.wig/.bed/;
	print $bed . "\n";
	#die;
	
	system("cat $in | ./FixStepToBedGraph.pl > $bed");
	
}