#!/usr/bin/perl
use strict; use warnings;

open IN, "<complete.tsv" or die "can't open complete.tsv\n";
open OUT, ">complete.bed" or die "can't open complete.bed\n";

while (<IN>) {
	my @line = split(/\s+/,$_);
	my ($chr,$start,$end) = ($line[0],$line[1],$line[2]);
	
	$start = $start - 1;
	
	my $val = $chr . ":" . $start . "-" . $end;
	
	print OUT "$chr\t$start\t$end\t" . "$val" . "\n";
}
close IN;
close OUT;